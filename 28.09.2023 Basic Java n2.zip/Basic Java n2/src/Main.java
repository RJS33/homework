public class Main {
    public static void main(String[] args) {
        int number2 = 345;
        int number3 = 987;
        int n1 = number2 / 100;
        int n2 = number2 % 100 / 10;
        int n3 = number2 % 10;
        int n4 = number3 / 100;
        int n5 = number3 % 100 / 10;
        int n6 = number3 % 10;

        System.out.println(n1);
        System.out.println(n2);
        System.out.println(n3);
        System.out.println(n4);
        System.out.println(n5);
        System.out.println(n6);
        System.out.println( "Число " + number2 + " -> " + n1 + ", " + n2 + ", " + n3);
        System.out.println( "Число " + number3 + " -> " + n4 + ", " + n5 + ", " + n6);


    }
}