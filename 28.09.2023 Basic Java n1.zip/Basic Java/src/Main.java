public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        char c = 'g';
        int i = 89;
        byte b = 4;
        short s = 56;
        float f = 4.7333436F;
        double d = 4.355453532;
        long l = 12121L;
        System.out.print(c);
        System.out.print(i);
        System.out.print(b);
        System.out.print(s);
        System.out.print(f);
        System.out.print(d);
        System.out.print(l);

    }
}